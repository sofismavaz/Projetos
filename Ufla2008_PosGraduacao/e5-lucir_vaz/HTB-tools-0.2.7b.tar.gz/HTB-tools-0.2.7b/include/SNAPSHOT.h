static char SNAPSHOT[] = "001007";
