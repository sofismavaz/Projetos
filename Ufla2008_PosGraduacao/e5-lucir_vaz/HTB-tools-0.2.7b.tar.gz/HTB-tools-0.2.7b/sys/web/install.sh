#!/bin/bash
# HTB-tools, q_show web install
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Author:     arny  <arny[at]arny.ro>
#

if [ `id -u` -ne 0 ]; then
        echo "This script must be run as root."
        exit -1
fi

echo 
echo "	Enter the directory where want to install q_show web."
echo "	eg.  /var/www/htdocs"
echo "directory: "; 
# Informa para o script de instalação o diretório web
# Alteração: Lucir Vaz
#read cale
cale="/var/www/htdocs"
if [ ! -d "$cale" ]; then
  mkdir -p "$cale"
  chmod +wrx "$cale"
fi
if [ -x $cale ]; then
	    echo "Installing files ..." 
	    mkdir -p $cale/webhtb
 	    /bin/cp "sys/web/q_show.php" $cale/webhtb/index.php
            echo "Done."  
            else
            echo "Directory not exist. Run make install_web again."
	    fi

