<html>
<head>
<title>Web htb - q_show - realtime trafic</title>
<META HTTP-EQUIV="refresh" content="60; url=q_show.php">
 <style>
  body, td, tr {font-family: Verdana;  font-size: 12px; }
  pre {font-family: Verdana;  font-size: 12px; }
  </style>
</head>
<body>
<center>
<table border=0 width=580 cellpadding=0 cellspacing=0>
<tr>
<td>

Realtime trafic <? echo date("l dS of F Y h:i:s A"); ?>
<hr width=580>

</td>
</tr>
<tr>
<td align=right>
web q_show - HTB-tools-0.2.7a - <a href="http://htb-tools.arny.ro">http://htb-tools.arny.ro</a>
</td>
</tr>


</table><p>
<table border=0 cellpadding=0 cellspacing=0>
<?
ob_start();
include "q_show.log";
$xx = ob_get_contents();
ob_end_clean();
//$xx = str_replace("\33[H\33[J", "", $xx);
$xx = str_replace("\33[H\33[J", "", $xx);
//$lines = explode("\n",$xx);
$lines = explode("\n",$xx);


// get number of clients
foreach ($lines as $key=>$val) {
    if (substr($val, 0, 1) == "#") {
        $class_names[] = str_replace("#CLASS: ", "", $val);
    } else {
        if (substr($val, 0, 1) != " ") {
            $vals = explode(" ", $val);
            $current_class = $vals[0];
        } else {
            $user_count[$current_class]++;
        }
    }
}
// end get number of clients

$counter = 0;
$bgcolor1 = "#FFFFFF";
$bgcolor2 = "#E9E9E9";
foreach ($lines as $key=>$val) {
    if (substr($val, 0, 1) == "#") {
        $class_name = str_replace("#CLASS: ", "", $val);
        if ($class_name == "suid") {
            echo "<tr><td bgcolor=\"#FFFFFF\"><font style=\"color: black\"><b>".$val."</b></font></td></tr>";
        } else {
          echo "<tr><td bgcolor=\"#FFFFFF\"><font style=\"color: black\"><b>".$val."</b> - ".$user_count[$class_name]." <b>users online</b></font></td></tr>";
        }
    } else {
        for ($ii=0; $ii<50; $ii++) {
            $val = str_replace("  "," ", $val);
        }
        $trs = explode(" ", $val);
        if (substr($val, 0, 1) != " " || substr($val, 0, 3) == " _D") {
                $val = trim($val);
                $trs = explode(" ", $val);
                $counter = 0;
            if (count($trs) > 2) {
                echo "<tr><td bgcolor=\"#D7D7FF\">";
                    echo "<table border=0 cellpadding=2 cellspacing=0>";
                    echo "<tr>";
                    $counter2 = 0;
                        foreach ($trs as $key2=>$val2) {
                            if ($counter2>0) {
                                echo "<td width=\"100\" align=\"right\"><b>".$val2."</b></td>";
                            } else {
                                echo "<td width=\"160\" align=\"left\"><b>".$val2."</b></td>";
                            }
                            $counter2++;
                        }
                    echo "</tr>";
                    echo "</table>";
                echo "</td></tr>";
            }
        } else {
            if (count($trs) > 2) {
                echo "<tr><td bgcolor=\"".($counter%2?$bgcolor1:$bgcolor2)."\">";
                    echo "<table border=0 cellpadding=2 cellspacing=0>";
                    echo "<tr>";
                    $counter2 = 0;
                        foreach ($trs as $key2=>$val2) {
                            if ($counter2>0) {
                            if ($counter2>1) {
                                echo "<td width=\"100\" align=\"right\">".$val2."</td>";
                            } else {
                                echo "<td width=\"160\" align=\"left\">&nbsp;&nbsp;".$val2."</td>";
                            }
                            }
                            $counter2++;
                        }
                    
		    echo "</tr>";
                    echo "</table>";
                echo "</td></tr>";
                $counter++;
            }
        }
    }    
}
?>

</table>
<center>
</body>
</html>

