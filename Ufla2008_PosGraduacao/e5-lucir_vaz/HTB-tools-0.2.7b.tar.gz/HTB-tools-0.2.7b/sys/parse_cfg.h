
int read_cfg (char *cfg_file);
